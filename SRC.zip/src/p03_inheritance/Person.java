package p03_inheritance;

public class Person {
    protected String role = "Person";

    protected void info() {
        System.out.println("Role: " + role);
    }
}
