package p03_inheritance;

public class Main {
    public static void main(String[] args) {
        Teacher t = new Teacher();
        t.info();
        t.teach();
    }
}
