package p01_classes_objects;

public class Book {
    String title;
    int price;

    void showDetails() {
        System.out.println("Book Title: " + title);
        System.out.println("Book Price: " + price);
    }
}
