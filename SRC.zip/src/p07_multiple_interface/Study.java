package p07_multiple_interface;

public interface Study {
    void read();
}
