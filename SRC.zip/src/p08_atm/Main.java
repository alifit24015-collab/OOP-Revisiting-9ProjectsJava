package p08_atm;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ATM atm = new ATM();
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("1.Deposit 2.Withdraw 3.Balance 4.Exit");
            choice = sc.nextInt();

            switch(choice) {
                case 1:
                    System.out.print("Enter amount: ");
                    atm.deposit(sc.nextInt());
                    break;
                case 2:
                    System.out.print("Enter amount: ");
                    atm.withdraw(sc.nextInt());
                    break;
                case 3:
                    atm.showBalance();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        } while(choice != 4);
    }
}
