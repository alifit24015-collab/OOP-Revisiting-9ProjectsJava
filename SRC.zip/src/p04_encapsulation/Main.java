package p04_encapsulation;

public class Main {
    public static void main(String[] args) {
        Employee e = new Employee();
        e.addBonus(8000);
        System.out.println("Salary: " + e.getSalary());
    }
}
