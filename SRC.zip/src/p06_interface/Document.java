package p06_interface;

public class Document implements Printable {
    public void print() {
        System.out.println("Document printing...");
    }
}
