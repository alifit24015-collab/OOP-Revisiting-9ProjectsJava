package p06_interface;

public class Main {
    public static void main(String[] args) {
        Printable doc = new Document();
        doc.print();
    }
}
